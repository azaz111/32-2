import os
import time
import datetime


time.sleep(250)
i = 0
while i < 1:
        time.sleep(10)
        
        fnon = open("/root/aknomber.txt", "r") 
        ns = fnon.readlines()
        nss = ns[1]
        nss = nss.replace('\n', '')
        nsp = ns[0]
        nsp = nsp.replace('\n', '')
        print(f"Imya Servera  :{nss}")
        
        sozd = '/root/aknomber.txt' # Р­С‚Рѕ С„Р°Р№Р» РґР°С‚С‹ СЃРѕР·РґР°РЅРёСЏ
        t2 = os.path.getctime(sozd)
        t2 = t2 + 10800
        print (f"Sozdan : ' {time.ctime(t2) } '")
        
        sub = ": Deleted"   # РЎР»РѕРІРѕ РґР»СЏ РїРѕРёСЃРєР°
        
        sfa = open("/root/rclone1.log", "r") 
        str1 = sfa.read()
        rcl1= str1.count(sub)
        #print(f"РџРµСЂРµРґР°РЅРЅРѕ РїР»РѕС‚РѕРІ 1:'{rcl1}'")
        
        sfa = open("/root/rclone2.log", "r") 
        str2 = sfa.read()
        rcl2= str2.count(sub)
        #print(f"РџРµСЂРµРґР°РЅРЅРѕ РїР»РѕС‚РѕРІ 2:'{rcl2}'")
        
        print(f"Plotov peredanno VSEGO  :'{rcl1+rcl2}'")
        
        files = os.listdir(path="/disk4/video")
        plot1 = len(files)
        files2 = os.listdir(path="/disk4/video1")
        plot2 = len(files2)
        print(f"Plotov na SERVERE : '{plot1+plot2}'")
        
        path = '/disk2/vid2'
        # Р­С‚Рѕ РїСѓС‚СЊ Рє С„Р°Р№Р»Сѓ РєРѕС‚РѕСЂС‹Р№ С‡Р°СЃС‚Рѕ РѕР±РЅРѕРІР»СЏРµС‚СЃСЏ 
        t = os.path.getmtime(path) # РґР°С‚Р° РїРѕСЃР»РµРґРЅРµРіРѕ РёР·РјРµРЅРµРЅРёСЏ С„Р°Р№Р»Р° РѕРЅР° Р¶Рµ РґР°С‚Р° РєРѕРЅРµРєС‚Р°
        t = t + 10800
        print (f"Poslednii raz v seti : ' {time.ctime(t)} '")
        #t1 = os.path.getmtime(file) # РґР°С‚Р° РїРѕСЃР»РµРґРЅРµРіРѕ РёР·РјРµРЅРµРЅРёСЏ С„Р°Р№Р»Р° 
        
        #t2 = os.path.getctime(file) # РґР°С‚Р° СЃРѕР·РґР°РЅРёСЏ С„Р°Р№Р»Р° - РјРѕР№ РјРѕРЅРёС‚РѕСЂРёРЅРі РґР°С‚С‹ СЃС‚Р°СЂС‚Р°
        
        #files32 = os.listdir(path="/root")
        #plot_vs = len(files32)
        #print (f"Na diske PLOTOV  : ' {plot_vs} '")
        #t2=1629754844.820516
        
        #if (time.time() - t) < 600 :
        #    print("РўРµРєСѓС‰РёР№ СЃС‚Р°С‚СѓСЃ : 'Online'")
        #else:
        #    print('РўРµРєСѓС‰РёР№ СЃС‚Р°С‚СѓСЃ : "Off-line"')
        
        #sub = input('Please enter a sub-string:\n') 
        t3 = t-t2
        t33 = time.gmtime(t3)
        print(f"Chasov V Seti : {t33.tm_hour}")

        tst = 150/(rcl1+rcl2+1)
        print(f"Tekischaya Rentabelnost : {tst} rub.plot")

        
        lines = [f"Imya Servera  :{nss}", f"Sozdan : {time.ctime(t2)} ", f"Peredano VSEGO  :{rcl1+rcl2}", f"Plotov na SERVERE: {plot1+plot2}" , f"Poslednii raz v seti : {time.ctime(t)}", f"Chasov V Seti : {t33.tm_hour}", f"Tekischaya Rentabelnost : {tst} rub.plot" ]

        with open(f"/root/{nss}_{nsp}", "w") as filef:
            for  line in lines:
                filef.write(line + '\n')
                #file.close()