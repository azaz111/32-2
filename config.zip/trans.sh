echo -n 'VVEDI NOMER : '
read int >> aknomber.txt #< akno.txt
echo "$int" >> aknomber.txt 
#read int  >> akno.txt
echo 'OK'
case $int in
  1 | 1-1)      x=0  ; lim=10  ;;
  11 | 1-2)     x=10  ; lim=20  ;;
  2 | 2-1)       x=20 ; lim=30  ;;
  21 | 2-2)     x=30  ; lim=40 ;;
  3 | 3-1)        x=40 ; lim=50  ;;
  31 | 3-2)     x=50 ; lim=60  ;;
  4 | 4-1)        x=60 ; lim=70  ;;
  41 | 4-2)     x=70  ; lim=80 ;;
  5 | 5-1)        x=80 ; lim=90  ;;
  51 | 5-2)      x=90  ; lim=100 ;;
  6 | 6-1)        x=100  ; lim=110 ;;
  61 | 6-2)      x=110 ; lim=120 ;;
  7 | 7-1)        x=120 ; lim=130 ;;
  71 | 7-2)      x=130 ; lim=140 ;;
  8 | 8-1)        x=140 ; lim=150 ;;
  81 | 8-2)      x=150 ; lim=160 ;;
  9 | 9-1)        x=160 ; lim=170 ;;
  91 | 9-2)      x=170 ; lim=180 ;;
  10 | 10-1)       x=180 ; lim=190 ;;
 101 | 10-2)     x=190 ; lim=200 ;;
  11-1 | 11-1)      x=200  ; lim=210  ;;
  11-2 | 11-2)     x=210  ; lim=220  ;;
  12 | 12-1)       x=220 ; lim=230  ;;
  121 | 12-2)     x=230  ; lim=240 ;;
  13 | 13-1)        x=240 ; lim=250  ;;
  131 | 13-2)     x=250 ; lim=260  ;;
  14 | 14-1)        x=260 ; lim=270  ;;
  141 | 14-2)     x=270  ; lim=280 ;;
  15 | 15-1)        x=280 ; lim=290  ;;
  151 | 15-2)      x=290  ; lim=300 ;;
  16 | 16-1)        x=300  ; lim=310 ;;
  161 | 16-2)      x=310 ; lim=320 ;;
  17 | 17-1)        x=320 ; lim=330 ;;
  171 | 17-2)      x=330 ; lim=340 ;;
  18 | 18-1)        x=340 ; lim=350 ;;
  181 | 18-2)      x=350 ; lim=360 ;;
  19 | 19-1)        x=360 ; lim=370 ;;
  191 | 19-2)      x=370 ; lim=380 ;;
  20 | 20-1)       x=380 ; lim=390 ;;
  201 | 20-2)     x=390 ; lim=400 ;;
  21 | 1-1)      x=400  ; lim=410  ;;
  211 | 1-2)     x=410  ; lim=420  ;;
  22 | 2-1)       x=420 ; lim=430  ;;
  221 | 2-2)     x=430  ; lim=440 ;;
  23 | 3-1)        x=440 ; lim=450  ;;
  231 | 3-2)     x=450 ; lim=460  ;;
  24 | 4-1)        x=460 ; lim=470  ;;
  241 | 4-2)     x=470  ; lim=480 ;;
  25 | 5-1)        x=480 ; lim=490  ;;
  251 | 5-2)      x=490  ; lim=500 ;;
  26 | 6-1)        x=500  ; lim=510 ;;
  261 | 6-2)      x=510 ; lim=520 ;;
  27 | 7-1)        x=520 ; lim=530 ;;
  271 | 7-2)      x=530 ; lim=540 ;;
  28 | 8-1)        x=540 ; lim=550 ;;
  281 | 8-2)      x=550 ; lim=560 ;;
  29 | 9-1)        x=560 ; lim=570 ;;
  291 | 9-2)      x=570 ; lim=580 ;;
  30 | 10-1)       x=580 ; lim=590 ;;
  301 | 10-2)     x=590 ; lim=600 ;;
  311 | 11-1)      x=600  ; lim=610  ;;
  311 | 11-2)     x=610  ; lim=620  ;;
  32 | 12-1)       x=620 ; lim=630  ;;
  321 | 12-2)     x=630  ; lim=640 ;;
  33 | 13-1)        x=640 ; lim=650  ;;
  331 | 13-2)     x=650 ; lim=660  ;;
  34 | 14-1)        x=660 ; lim=670  ;;
  341 | 14-2)     x=670  ; lim=680 ;;
  35 | 15-1)        x=680 ; lim=690  ;;
  351 | 15-2)      x=690  ; lim=700 ;;
  36 | 16-1)        x=700  ; lim=710 ;;
  361 | 16-2)      x=710 ; lim=720 ;;
  37 | 17-1)        x=720 ; lim=730 ;;
  371 | 17-2)      x=730 ; lim=740 ;;
  38 | 18-1)        x=740 ; lim=750 ;;
  381 | 18-2)      x=750 ; lim=760 ;;
  39 | 19-1)        x=760 ; lim=770 ;;
  391 | 19-2)      x=770 ; lim=780 ;;
  40 | 20-1)       x=780 ; lim=790 ;;
  401 | 20-2)     x=790 ; lim=800 ;;
  *)
    echo -e "Ne vveden/Ne korekten nomer AKKA \n"
    ./trans.sh
    ;;
esac


i=1
while [ $i -le 5 ]
do
x=$(( $x + 1 ))
echo "schetchekSA: $x"
pkill rclone
screen -dmS trans1 rclone move /disk3/video was: --drive-stop-on-upload-limit --transfers 2 -P --drive-service-account-file "/root/AutoRclone/accounts/$(( $x )).json" -v --log-file /root/rclone1.log;
sleep 20
x=$(( $x + 1 ))
screen -dmS trans2 rclone move /disk3/video1 was: --drive-stop-on-upload-limit --transfers 2 -P --drive-service-account-file "/root/AutoRclone/accounts/$(( $x )).json" -v --log-file /root/rclone2.log;
sleep 3500
if [ $x = $lim ]; then x=$(( $x - 10 )) ; fi
done
 
