screen -dmS trans1 aws s3 mv disk3/video s3://pb1/ --recursive 
sleep 20
screen -dmS trans2 aws s3 mv disk3/video1 s3://pb1/ --recursive 
sleep 3500
done
 
