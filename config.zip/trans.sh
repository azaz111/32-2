echo -n 'VVEDI NOMER : '
read int >> aknomber.txt #< akno.txt
echo "$int" >> aknomber.txt 
#read int  >> akno.txt
echo 'OK'
case $int in
  1 | 1-1)      x=0  ; lim=10  ;;
  11 | 1-2)     x=10  ; lim=20  ;;
  2 | 2-1)       x=20 ; lim=30  ;;
  21 | 2-2)     x=30  ; lim=40 ;;
  3 | 3-1)        x=40 ; lim=50  ;;
  31 | 3-2)     x=50 ; lim=60  ;;
  4 | 4-1)        x=60 ; lim=70  ;;
  41 | 4-2)     x=70  ; lim=80 ;;
  5 | 5-1)        x=80 ; lim=90  ;;
  51 | 5-2)      x=90  ; lim=100 ;;
  6 | 6-1)        x=100  ; lim=110 ;;
  61 | 6-2)      x=110 ; lim=120 ;;
  7 | 7-1)        x=120 ; lim=130 ;;
  71 | 7-2)      x=130 ; lim=140 ;;
  8 | 8-1)        x=140 ; lim=150 ;;
  81 | 8-2)      x=150 ; lim=160 ;;
  9 | 9-1)        x=160 ; lim=170 ;;
  91 | 9-2)      x=170 ; lim=180 ;;
  10 | 10-1)       x=180 ; lim=190 ;;
 101 | 10-2)     x=190 ; lim=200 ;;
  11-1 | 11-1)      x=200  ; lim=210  ;;
  11-2 | 11-2)     x=210  ; lim=220  ;;
  12 | 12-1)       x=220 ; lim=230  ;;
  121 | 12-2)     x=230  ; lim=240 ;;
  13 | 13-1)        x=240 ; lim=250  ;;
  131 | 13-2)     x=250 ; lim=260  ;;
  14 | 14-1)        x=260 ; lim=270  ;;
  141 | 14-2)     x=270  ; lim=280 ;;
  15 | 15-1)        x=280 ; lim=290  ;;
  151 | 15-2)      x=290  ; lim=300 ;;
  16 | 16-1)        x=300  ; lim=310 ;;
  161 | 16-2)      x=310 ; lim=320 ;;
  17 | 17-1)        x=320 ; lim=330 ;;
  171 | 17-2)      x=330 ; lim=340 ;;
  18 | 18-1)        x=340 ; lim=350 ;;
  181 | 18-2)      x=350 ; lim=360 ;;
  19 | 19-1)        x=360 ; lim=370 ;;
  191 | 19-2)      x=370 ; lim=380 ;;
  20 | 20-1)       x=380 ; lim=390 ;;
  201 | 20-2)     x=390 ; lim=400 ;;
  *)
    echo -e "Ne vveden/Ne korekten nomer AKKA \n"
    ./trans.sh
    ;;
esac


i=1
while [ $i -le 5 ]
do
x=$(( $x + 1 ))
echo "schetchekSA: $x"
pkill rclone
screen -dmS trans1 rclone move /disk4/osnova aws32: --drive-stop-on-upload-limit --transfers 2 -P --drive-service-account-file "/root/AutoRclone/accounts/$(( $x )).json" -v --log-file /root/rclone1.log;
screen -dmS btrans1 rclone move /disk4/beckup baws32: --drive-stop-on-upload-limit --transfers 2 -P --drive-service-account-file "/root/AutoRclone/baccounts/$(( $x )).json" -v --log-file /root/brclone1.log;
sleep 20
x=$(( $x + 1 ))
screen -dmS trans2 rclone move /disk4/osnova1 aws32: --drive-stop-on-upload-limit --transfers 2 -P --drive-service-account-file "/root/AutoRclone/accounts/$(( $x )).json" -v --log-file /root/rclone2.log;
screen -dmS btrans2 rclone move /disk4/beckup1 baws32: --drive-stop-on-upload-limit --transfers 2 -P --drive-service-account-file "/root/AutoRclone/baccounts/$(( $x )).json" -v --log-file /root/brclone2.log;
sleep 3500
if [ $x = $lim ]; then x=$(( $x - 10 )) ; fi
done
 
